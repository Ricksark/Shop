const AFFILIATE_TAG = "royalkrrish00-21"; // Apna Tag Yahan Daalo

const products = [
    "https://amzn.to/48NI9pI",
    "https://www.amazon.in/dp/B0DTTZ86TV",
    "https://amzn.to/491Lwbp",
    "https://amzn.to/48OzQKr",
    "https://amzn.to/4arvYAe",
    "https://amzn.to/4qq0Tlf",
    "https://amzn.to/4pXMDQH",
    "https://amzn.to/3KVZjs8",
    "https://amzn.to/3YBlKWy",
    "https://amzn.to/44BTPcC",
    "https://amzn.to/4pKbPKh",
    "https://amzn.to/4qFkRbR",
    // Aur links yahan comma (,) laga ke add karte jao
];
